const mysql = require('mysql');

const mysqlCon = mysql.createConnection({
    host:process.env.db_host,
    user: process.env.db_user,
    password:process.env.db_pass,
    database: process.env.db_name
});

mysqlCon.connect((err)=> {
    if(!err)
    console.log('Conexão com o BD feita');
    else
    console.log('Deu ruim :('+ err);
});

module.exports=mysqlCon;