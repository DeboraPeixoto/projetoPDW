require('dotenv').config({path:'var.env'});
const express = require('express');
const cors = require ('cors');
const bp = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
//const salRounds = 10;


const routes = require('./routes');
const { append } = require('express/lib/response');

const server = express();
server.use(cors());
server.use(bp.urlencoded({extended: false}));
server.use(bp.json());
server.use(session({
    secret: 'user',
    resave : true,
    saveUninitialized: true,

}));
server.use('/api', routes);

server.listen(process.env.PORTA, ()=>{console.log(`Server rodando em http://localhost:${process.env.PORTA}`);});

/*projeto jeito com auxílio do mini-curso API com Node.Js e MySql, do Professor Lozano (/https://www.youtube.com/watch?v=boQfcrc6b6A&list=PL1hl9qLyFtfDXY9NO8F3TnjxezKJ_1HlI&index=2&ab_channel=ProfessorLozano)*/