const TransacServico = require('../servicos/TransacServico');

module.exports = {
    
    getTransac: async (req, res) => {
        let json = {error:'', result:[]};

        let transacao = await TransacServico.getTransac();

        for(let i in transacao){
            json.result.push({
                id_transac: transacao[i].id_transac,
                id_compr:transacao[i].id_compr,
                id_item:transacao[i].id_item,
                dt_transac:transacao[i].dt_transac,
                vlr_transac:transacao[i].vlr_transac
            });
        }
        res.json(json);
    },

    getUmaTransac: async (req, res) => {
        let json = {error:'', result:{}};

        let id_transac = req.params.id_transac;
        let transac = await TransacServico.getUmaTransac(id_transac);

        if(transac){
            json.result = transac;
            }
        res.json(json); 
    },

    addTransac: async(req, res) => {
        let json = {error:'', result:{}};

        let id_compr = req.body.id_compr;
        let id_item = req.body.id_item;
        let dt_transac = req.body.dt_transac;
        let vlr_transac = req.body.vlr_transac;

        if (id_compr && id_item && dt_transac && vlr_transac){
            let TransacId = await TransacServico.addTransac( id_compr, id_item, dt_transac, vlr_transac);
            json.result = {
                id: TransacId,
                id_compr,
                id_item,
                dt_transac,
                vlr_transac
            };
        }else{
            json.error = 'Campos não enviados';
        }
        res.json(json);
    }

}