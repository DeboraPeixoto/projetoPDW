const ItemServico = require('../servicos/ItemServico');

module.exports = {
    
    getItens: async (req, res) => {
        let json = {error:'', result:[]};

        let itens = await ItemServico.getItens();

        for(let i in itens){
            json.result.push({
                id: itens[i].id,
                titulo:itens[i].titulo,
                categoria:itens[i].categoria,
                preco:itens[i].preco,
                descricao:itens[i].descricao,
                status_item: itens[i].status_item,
                dt_edicao: itens[i].dt_edicao,
                periodicidade:  itens[i].periodicidade,
                id_vendedor: itens[i].id_vendedor,
            });
        }
        
        res.json(json);
    },

    getUmItem: async (req, res) => {
        let json = {error:'', result:{}};

        let id = req.params.id;
        let itens = await ItemServico.getUmItem(id);

        if(itens){
            json.result = itens;
            }
            console.log('testebuscaritem')
        res.json(json);   
    },

//     getAllUsuariosInat: async (req, res) => {
//         let json = {error:'', result:[]};

//         let usuario = await UserServico.getAllUsuarios();

//         for(let i in usuario){
//             json.result.push({
//                 id: usuario[i].id,
//                 nome:usuario[i].nome,
//                 tp_usuario:usuario[i].tp_usuario,
//                 email:usuario[i].email,
//                 senha:usuario[i].senha,
//                 is_inativo: usuario[i].is_inativo
//             });
//         }

//         res.json(json);
//     },
    



    addItem: async(req, res) => {
        let json = {error:'', result:{}};

        let titulo = req.body.titulo;
        let categoria = req.body.categoria;
        let preco = req.body.preco;
        let descricao = req.body.descricao;
        let status_item = req.body.status_item;
        let dt_edicao = req.body.dt_edicao;
        let periodicidade = req.body.periodicidade;
        let id_vendedor = req.body.id_vendedor;

    if (titulo && categoria && preco && descricao && status_item && dt_edicao && periodicidade && id_vendedor){
        let ItemCod = await ItemServico.addItem(titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor);
        json.result = {
            id: ItemCod,
            titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor
        };
    }else{
        json.error = 'Campos não enviados';
    }
    res.json(json);
}

//     altUsuario: async (req, res) => {
//         let json = {error:'', result:{}};

//         let id = req.params.id;
//         let nome = req.body.nome;
//         let tp_usuario = req.body.tp_usuario;
//         let email = req.body.email;
//         let senha = req.body.senha;
//         let is_inativo = req.body.is_inativo;
        
//         if (id && nome && tp_usuario && email && senha && is_inativo) {
//                 await UserServico.altUsuario(id, nome,tp_usuario,email,senha,is_inativo);
//             json.result = {
//                 id,
//                 nome,
//                 tp_usuario,
//                 email,
//                 senha,
//                 is_inativo
//             };
//         } else {
//             json.error = 'erro ao realizar a alteração';
//         }
     
//         res.json(json);
//     },


//     delUsuario: async (req, res) => {
//         let json = {error:'', result:{}};
//         await UserServico.delUsuario(req.params.id);
    
//         res.json(json);
        
           
//     }


 }