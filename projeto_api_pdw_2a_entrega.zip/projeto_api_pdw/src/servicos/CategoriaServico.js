const db = require('../db');

module.exports = {
    getCat: () => {
        return new Promise((accept, reject)=>{
            console.log('teste1');
            db.query('SELECT * FROM categoria', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    getCatInat: () => {
        return new Promise((accept, reject)=>{
            console.log('teste1');
            db.query('SELECT * FROM categoria_inativa', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    getUmaCat: (id) => {
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM categoria WHERE id = ?', [id], (error, results) => {
                console.log('testebuscarcat2')
                if(error) { reject(error); return; }
                if(results.length > 0){ 
                    accept(results[0]);
                }else {
                    accept(false);
                }
            });
        });
    },

    addCat: (nome, descricao)=> {
        return new Promise((aceito, rejeitado)=> {
            console.log('teste2');
            db.query('INSERT INTO categoria (nome, descricao) VALUES (?, ?)',
                [nome, descricao],
                (error, results)=>{
                    if(error){ rejeitado(error); return; }
                    aceito(results.insertCodigo); //insertId
                }
            );
        });
    },

    altCat: (id, nome, descricao) => {
        return new Promise((accept, reject)=>{

            db.query('UPDATE categoria set nome = ?, descricao = ? where id = ?', [nome, descricao, id],
            (error, results)=>{
                if(error) { reject(error); return; }
                accept(results);
            });
        });
    },

    delCat: (id)=> {
        return new Promise((accept, reject)=> {
            db.query('DELETE FROM categoria WHERE id = ?',[id], (error, results ) =>{
                if(error){ reject(error); return; }
                accept(results);
                console.log('teste delete')
            });
        });
    } 
        
}
    
    














