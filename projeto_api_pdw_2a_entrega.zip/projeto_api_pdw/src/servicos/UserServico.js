const db = require('../db');

module.exports = {
    getAllUsuarios: () => {
        console.log('teste1');
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM usuario', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    getAllUsuariosInat: () => {
        console.log('teste1');
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM usuario_inativo', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    addUsuario: (nome, tp_usuario, email, senha, is_inativo)=> {
        return new Promise((accept, reject)=>{

            db.query('INSERT INTO usuario (nome, tp_usuario, email, senha, is_inativo) values (?,?,?,?,?)', [nome, tp_usuario, email, senha, is_inativo],
            (error, results)=>{
                if(error) { reject(error); return; }
                accept(results.insertId);
                console.log('teste');
            });
        });
    },

    altUsuario: (id, nome, tp_usuario, email, senha, is_inativo) => {
        return new Promise((accept, reject)=>{
            db.query('UPDATE usuario set nome = ?, tp_usuario=?, email=?, senha=?, is_inativo=? where id = ?', [nome, tp_usuario, email, senha, is_inativo, id],
            (error, results)=>{
                if(error) { reject(error); return;}
                accept(results);
                console.log('terminou')
            });
        });
    },

    delUsuario: (id)=> {
        return new Promise((aceito, rejeitado)=> {
            db.query('DELETE FROM usuario WHERE id = ?',[id], (error, results ) =>{
                if(error){ rejeitado(error); return; }
                aceito(results);
                console.log('teste delete')
            });
        });
    } 
        
}
    
    














// AddUsuario:(nome, data_nascimento, is_comprador, is_vendedor,tp_usuario,login, senha, is_inativo) => {
//     console.log('teste3');
//     return new Promise((accept, reject)=>{
//         console.log('teste');
//         db.query('INSERT INTO usuario (nome, data_nascimento,is_comprador,is_vendedor,tp_usuario,login,senha,is_inativo) values (?,?,?,?,?,?,?,?)',[nome, data_nascimento,is_comprador,is_vendedor,tp_usuario,login,senha,is_inativo],(error, results)=>{
            
//             if(error)
//             {console.log(error);
//             rejected(error);

//             return;
//             }
//             accept(results.insertId);
//         }
//     );
// });
// }