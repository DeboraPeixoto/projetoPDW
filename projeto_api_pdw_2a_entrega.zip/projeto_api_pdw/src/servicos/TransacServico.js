const db = require('../db');

module.exports = {
    getTransac: () => {
        console.log('teste1');
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM transac', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    getUmaTransac: (id_transac) => {
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM transac where id_transac = ?', [id_transac], (error, results) => {
               
                if(error) { reject(error); return; }
                if(results.length > 0){ 
                    accept(results[0]);
                }else {
                    accept(false);
                }
            });
        });
    },

    addTransac: (id_compr, id_item, dt_transac, vlr_transac)=> {
        return new Promise((aceito, rejeitado)=> {

            db.query('INSERT INTO transac (id_compr, id_item, dt_transac, vlr_transac) VALUES ( ?, ?, ?, ?)',
                [id_compr, id_item, dt_transac, vlr_transac],
                (error, results)=>{
                    if(error){ rejeitado(error); return; }
                    aceito(results.insertCodigo); //insertId
                }
            );
        });
    }
}