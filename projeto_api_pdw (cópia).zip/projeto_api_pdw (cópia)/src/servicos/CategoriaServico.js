const db = require('../db');

module.exports = {
    getCat: () => {
        return new Promise((accept, reject)=>{
            console.log('teste1');
            db.query('SELECT * FROM categoria', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    addCat: (nome, descricao)=> {
        return new Promise((aceito, rejeitado)=> {
            console.log('teste2');
            db.query('INSERT INTO categoria (nome, descricao) VALUES (?, ?)',
                [nome, descricao],
                (error, results)=>{
                    if(error){ rejeitado(error); return; }
                    aceito(results.insertCodigo); //insertId
                }
            );
        });
    },

    altCat: (id, nome, descricao) => {
        return new Promise((accept, reject)=>{

            db.query('UPDATE categoria set nome = ?, descricao = ? where id = ?', [nome, descricao, id],
            (error, results)=>{
                if(error) { reject(error); return; }
                accept(results);
            });
        });
    } 
        
}
    
    














