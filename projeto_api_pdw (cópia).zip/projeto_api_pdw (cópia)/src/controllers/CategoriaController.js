const CategoriaServico = require('../servicos/CategoriaServico');

module.exports = {
    
    getCat: async (req, res) => {
        let json = {error:'', result:[]};

        let cat = await CategoriaServico.getCat();

        for(let i in cat){
            json.result.push({
                id: cat[i].id,
                nome:cat[i].nome,
                descricao:cat[i].descricao
            });
        }

        res.json(json);
    },

    addCat: async(req, res) => {
        let json = {error:'', result:{}};

        let nome = req.body.nome;
        let descricao = req.body.descricao;

        if (nome && descricao){
            let CatCod = await CategoriaServico.addCat(nome, descricao);
            json.result = {
                codigo: CatCod,
                nome,
                descricao
            };
        }else{
            json.error = 'erro ao realizar cadastro';
        }
        res.json(json);
    },

    altCat: async (req, res) => {
        let json = {error:'', result:{}};

        let id = req.params.id;
        let nome = req.body.nome;
        let descricao = req.body.descricao;
        
        if (id && nome && descricao) {
                await CategoriaServico.altCat(id, nome, descricao);
            json.result = {
                id,
                nome,
                descricao
            };
        } else {
            json.error = 'erro ao realizar a alteração';
        }
     
        res.json(json);
    }
}