const db = require('../db');

module.exports = {
    getAdms: () => {
        console.log('teste1');
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM adm', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    }}