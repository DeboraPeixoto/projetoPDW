const ItemController = require('../controllers/ItemController');
const db = require('../db');

module.exports = {
    getItens: () => {
        console.log('teste1');
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM itens', (error, results)=>{
                if(error) { reject(error); return;  }
                accept(results);
            });
        });
    },

    getUmItem: (id) => {
        return new Promise((accept, reject)=>{

            db.query('SELECT * FROM itens WHERE id = ?', [id], (error, results) => {
                console.log('testebuscaritem22')
                if(error) { reject(error); return; }
                if(results.length > 0){ 
                    accept(results[0]);
                }else {
                    accept(false);
                }
            });
        });
    },

    addItem: (titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor)=> {
        return new Promise((aceito, rejeitado)=> {

            db.query('INSERT INTO itens (titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor) VALUES ( ?, ?,?,?,?,?,?,?)',
                [titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor],
                (error, results)=>{
                    if(error){ rejeitado(error); return; }
                    aceito(results.insertCodigo); //insertId
                }
            );
        });
    },

    altItem: (id, titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor) => {
        return new Promise((accept, reject)=>{

            db.query('UPDATE itens set id = ?, titulo = ?, categoria = ?, preco = ?, descricao = ?, status_item = ?, dt_edicao = ?, periodicidade = ?, id_vendedor= ? where id = ?', [id, titulo, categoria, preco, descricao, status_item, dt_edicao, periodicidade, id_vendedor],
            (error, results)=>{
                if(error) { reject(error); return; }
                accept(results);
            });
        });
    },

    buscarItem: (titulo) => {
        return new Promise((aceitar, rejeitar) => {
          db.query('SELECT * FROM itens WHERE titulo = ?', [titulo], (error, results) => {
            if (error) {
              rejeitar(error);
            } else {
              aceitar(results);
            }
          });
        });
      },

      buscarPrec: (preco) => {
        return new Promise((aceitar, rejeitar) => {
          db.query('SELECT * FROM itens WHERE preco = ?', [preco], (error, results) => {
            if (error) {
              rejeitar(error);
            } else {
              aceitar(results);
            }
          });
        });
      },

      buscarAut: (autor) => {
        return new Promise((aceitar, rejeitar) => {
          db.query('SELECT * FROM itens WHERE autor = ?', [autor], (error, results) => {
            if (error) {
              rejeitar(error);
            } else {
              aceitar(results);
            }
          });
        });
      }
      
}


//     getAllUsuariosInat: () => {
//         console.log('teste1');
//         return new Promise((accept, reject)=>{

//             db.query('SELECT * FROM usuario_inativo', (error, results)=>{
//                 if(error) { reject(error); return;  }
//                 accept(results);
//             });
//         });
//     },

    



//     altUsuario: (id, nome, tp_usuario, email, senha, is_inativo) => {
//         return new Promise((accept, reject)=>{
//             db.query('UPDATE usuario set nome = ?, tp_usuario=?, email=?, senha=?, is_inativo=? where id = ?', [nome, tp_usuario, email, senha, is_inativo, id],
//             (error, results)=>{
//                 if(error) { reject(error); return;}
//                 accept(results);
//                 console.log('terminou')
//             });
//         });
//     },

//     delUsuario: (id)=> {
//         return new Promise((aceito, rejeitado)=> {
//             db.query('DELETE FROM usuario WHERE id = ?',[id], (error, results ) =>{
//                 if(error){ rejeitado(error); return; }
//                 aceito(results);
//                 console.log('teste delete')
//             });
//         });
//     } 
        
 
    
    














// AddUsuario:(nome, data_nascimento, is_comprador, is_vendedor,tp_usuario,login, senha, is_inativo) => {
//     console.log('teste3');
//     return new Promise((accept, reject)=>{
//         console.log('teste');
//         db.query('INSERT INTO usuario (nome, data_nascimento,is_comprador,is_vendedor,tp_usuario,login,senha,is_inativo) values (?,?,?,?,?,?,?,?)',[nome, data_nascimento,is_comprador,is_vendedor,tp_usuario,login,senha,is_inativo],(error, results)=>{
            
//             if(error)
//             {console.log(error);
//             rejected(error);

//             return;
//             }
//             accept(results.insertId);
//         }
//     );
// });
