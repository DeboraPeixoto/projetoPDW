const express = require ('express');
const router = express.Router();

module.exports = {
    'secret': 'supersecret'};

const UserController = require('./controllers/UsuarioController');
const CategoriaController = require('./controllers/CategoriaController');
const UsuarioController = require('./controllers/UsuarioController');
const ItemController = require('./controllers/ItemController');
const db = require('./db');
const TransacController = require('./controllers/TransacController');
const AdmController = require('./controllers/AdmController');
/*const db = require('mysql/lib/protocol/constants/charsets');*/

router.get('/AllUsuarios', UserController.getAllUsuarios);
router.get('/AllUsuariosInat', UserController.getAllUsuariosInat);
router.post('/InsertUsuario', UserController.addUsuario);
router.put('/AltUsuario:id', UserController.altUsuario);
router.delete('/DelUsuario:id', UserController.delUsuario);
router.get('/', function(req, res, next){res.render('index', {title:'Express', session : req.session});});
router.post('/login', function(request, response, next){
    const email = request.body.email;
    const senha = request.body.senha;
    if(email && senha)
    {
        query = `
        select * from usuario
        where email = "${email}"`;

        db.query(query, function(error, data){
            if (data.length > 0 ){
                for(var c = 0; c < data.length;c++){
                    if(data[c].senha == senha){
                        request.session.id = data[c].id;

                        response.send("Login feito com sucesso");
                    } else {

                        response.send('Senha incorreta')
                    }
                }
            }else{
                response.send('Dados para autenticação incorretos');
            } response.end();
        });
    }
    else
    {
        response.send('Autenticação negada');
        response.end();
    }
});
router.get('/logout', function (request,response,next){
    request.session.destroy();
    response.redirect("/");
});
router.post('/loginadm', function(request, response, next){
    const email = request.body.email;
    const senha = request.body.senha;
    if(email && senha)
    {
        query = `
        select * from usuario
        where email = "${email}"`;

        db.query(query, function(error, data){
            if (data.length > 0 ){
                for(var c = 0; c < data.length;c++){
                    if(data[c].senha == senha){
                        request.session.id = data[c].id;

                        response.send("Login feito com sucesso");
                    } else {

                        response.send('Senha incorreta')
                    }
                }
            }else{
                response.send('Dados para autenticação incorretos');
            } response.end();
        });
    }
    else
    {
        response.send('Autenticação negada');
        response.end();
    }
});
router.get('/AdmUsuarios', AdmController.getAdms);
router.get('/Categorias', CategoriaController.getCat);
router.post('/Categorias', CategoriaController.addCat);
router.put('/Categorias/:id', CategoriaController.altCat);
router.get('/Categorias/:id', CategoriaController.getUmaCat);
router.delete('/Categorias/:id', CategoriaController.delCat);
router.get('/CategoriasInat', CategoriaController.getCatInat);

router.post('/Itens', ItemController.addItem);
router.get('/Itens', ItemController.getItens);
router.get('/Itens/:id', ItemController.getUmItem);
router.put('/Itens/:id', ItemController.altItem);
router.get('/ItensTit', ItemController.buscarItem);
router.get('/ItensPrec', ItemController.buscarPrec);
router.get('/ItensAut', ItemController.buscarAut);

// router.put('/EditarItem:id', ItemController.altItem);
// router.delete('/DelItem:id', ItemController.delItem);
// router.delete('/DelUsuario:id', ItemController.delUsuario);

router.get('/Transac', TransacController.getTransac);
router.get('/Transac/:id_compr', TransacController.getUmaTransac);
router.post('/Transac', TransacController.addTransac);

/*router.post('/AdmLogin', UserController.logAdm);
/*router.get('/AdmReports', UserController.repAdm)





/*router.post('/Transacao', UserController.addTransacao);
/*router.get('/Transacao:id', UserController.getTransacaoUser);

/*router.post('/Categorias', UserController.addCat);
*router.get('/Categorias', UserController.getCat);
/*router.put('/Categorias:id', UserController.altCat);
/*router.delete('/Categorias:id', UserController.delCat);

*/





module.exports = router;