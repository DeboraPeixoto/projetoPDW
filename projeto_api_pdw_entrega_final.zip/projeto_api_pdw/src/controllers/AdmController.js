const AdmServico = require('../servicos/AdmServico');

module.exports = {
    
    getAdms: async (req, res) => {
        let json = {error:'', result:[]};

        let adm = await AdmServico.getAdms();

        for(let i in adm){
            json.result.push({
                id: adm[i].id,
                id_user:adm[i].id_user,
                dt_inicio:adm[i].dt_inicio,
                especializacao:adm[i].especializacao,
            });
        }
        
        res.json(json);
    }
}
    