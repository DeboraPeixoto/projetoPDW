const UserServico = require('../servicos/UserServico');

var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');


module.exports = {
    
    getAllUsuarios: async (req, res) => {
        let json = {error:'', result:[]};

        let usuario = await UserServico.getAllUsuarios();

        for(let i in usuario){
            json.result.push({
                id: usuario[i].id,
                nome:usuario[i].nome,
                tp_usuario:usuario[i].tp_usuario,
                email:usuario[i].email,
                senha:usuario[i].senha,
                is_inativo: usuario[i].is_inativo
            });
        }

        res.json(json);
    },

    getAllUsuariosInat: async (req, res) => {
        let json = {error:'', result:[]};

        let usuario = await UserServico.getAllUsuarios();

        for(let i in usuario){
            json.result.push({
                id: usuario[i].id,
                nome:usuario[i].nome,
                tp_usuario:usuario[i].tp_usuario,
                email:usuario[i].email,
                senha:usuario[i].senha,
                is_inativo: usuario[i].is_inativo
            });
        }

        res.json(json);
    },

    addUsuario: async (req, res) => {
        let json = {error:'', result:{}};

        let nome = req.body.nome;
        let tp_usuario = req.body.tp_usuario;
        let email = req.body.email;
        let senha = bcrypt.hashSync(req.body.senha, 12);
       console.log('testiii')
        let is_inativo = req.body.is_inativo;
        if (nome && tp_usuario && email && senha && is_inativo) {
                let UsuarioInsert = await UserServico.addUsuario(nome, tp_usuario,email,senha,is_inativo);
            json.result = {
                id_user: UsuarioInsert,
                nome,
                tp_usuario,
                email,
                senha,
                is_inativo
            };
        } else {
            json.error = 'erro ao realizar o cadastro aqui';
        }
     
        res.json(json);
        console.log('auaua')
    },

    altUsuario: async (req, res) => {
        let json = {error:'', result:{}};

        let id = req.params.id;
        let nome = req.body.nome;
        let tp_usuario = req.body.tp_usuario;
        let email = req.body.email;
        let senha = req.body.senha;
        let is_inativo = req.body.is_inativo;
        
        if (id && nome && tp_usuario && email && senha && is_inativo) {
                await UserServico.altUsuario(id, nome,tp_usuario,email,senha,is_inativo);
            json.result = {
                id,
                nome,
                tp_usuario,
                email,
                senha,
                is_inativo
            };
        } else {
            json.error = 'erro ao realizar a alteração';
        }
     
        res.json(json);
    },


    delUsuario: async (req, res) => {
        let json = {error:'', result:{}};
        await UserServico.delUsuario(req.params.id);
    
        res.json(json);
        
           
    }


}